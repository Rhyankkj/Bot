const Discord = require("discord.js");

module.exports = {
    name: "channel-info",
    description: "Ver as informações de um canal.",
    type: Discord.ApplicationCommandType.ChatInput,
    options: [{name: 'canal', description: `Coloque um canal`, type: 7, required: false}],
    run: async (client, interaction) => {

    let ca = interaction.options.getChannel('canal') || interaction.channel;

    let nome = ca.name;
    let id = ca.id;
    let categoria = ca.parent === null ? 'Não Encontrada' : ca.parent.name;
    let type = ca.type;
    let mencao = `<#${ca.id}>`

      let e = new Discord.EmbedBuilder()
      .setTitle(`Channel Indo ${ca.name}`)
      .addFields({name: `Nome`, value: `${nome}`},
                 {name: `Id`, value: `${id}`},
                 {name: `Categoria`, value: `${categoria}`}, 
                 {name: `Menção`, value: `${mencao}`})
      .setColor('#00090f')
      .setFooter({text: `Executado por: ${interaction.user.username}`})


      interaction.reply({embeds: [e]})

}}