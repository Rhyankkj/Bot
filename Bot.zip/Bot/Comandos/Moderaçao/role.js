const Discord = require("discord.js")

module.exports = {
    name: 'role',
    description: 'Pegue um cargo com slash',
    options: [
        {
            name: 'cargo_id',
            description: 'Coloque o cargo.',
            type: Discord.ApplicationCommandOptionType.Role,
            required: true
        },
        {
            name: "member",
            description: "Selecione um membro",
            type: Discord.ApplicationCommandOptionType.User,
            required: true
        },
    ],
    

 run: async (client, inter) => {
         let cargo = inter.options.getRole("cargo_id")
         let target = inter.options.getMember("member")

        if (inter.guild.roles.cache.get(cargo.id).position >= inter.member.roles.highest.position) 
            return inter.reply({
                content: `❌ **| Você não pode pegar o cargo \`${cargo.name}\` porque você não possui ele.**`,
                ephemeral: true
            })
        inter.reply({
            content: `✔️ ${inter.user}, Você resgatou o cargo com sucesso!`,
            ephemeral: true
        })

        target.roles.add(cargo.id).catch(err => { console.log(err) } )
    }
}