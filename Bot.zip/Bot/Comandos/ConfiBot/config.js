const Discord = require('discord.js')

module.exports = {
    name: 'bot',
    description: 'Gerenciar aplicação',
    options: [
        {
            name: 'config',
            description: 'Gerenciar aplicação',
            type: Discord.ApplicationCommandOptionType.Subcommand
        }
    ],

    run: async (client, interaction) => {

        if (interaction.user.id != "909840929135919125") { // colocar o id de quem vai ter a perm.
            return interaction.reply({
                embeds: [
                    new Discord.EmbedBuilder()
                        .setDescription(`**${interaction.user.tag}**, Você não tem permissão para usar este comando.`)
                        .setColor("#00090f")
                        .setTimestamp()
                ],
                ephemeral: true,
            })
        } else {

            interaction.reply({
                components: [
                    new Discord.ActionRowBuilder()
                        .addComponents(
                            new Discord.ButtonBuilder()
                                .setCustomId("alterar_username")
                                .setLabel("Alterar Username")
                                .setEmoji("<:tag:1013500029341814864>")
                                .setStyle(Discord.ButtonStyle.Secondary),
                            new Discord.ButtonBuilder()
                                .setCustomId("alterar_avatar")
                                .setLabel("Alterar Avatar")
                                .setEmoji("<:picture:1007454364039921694>")
                                .setStyle(Discord.ButtonStyle.Secondary),
                        )
                ],
                embeds: [
                    new Discord.EmbedBuilder()
                        .setDescription(`Para me configurar clique nos botões abaixo de acordo com oque você dessejar.`)
                        .setColor("#00090f")
                        .setImage("")
                        .setTimestamp()
                        .setFooter({ text: client.user.username, iconURL: client.user.displayAvatarURL({ dinamyc: true }) })
                ],
                ephemeral: true,
            })
        }
    }
}