const Discord = require("discord.js")

const config = require("./config.json")

const client = new Discord.Client({ 
  intents: [ 
Discord.GatewayIntentBits.Guilds
       ]
    });

module.exports = client

client.on('interactionCreate', (interaction) => {

  if(interaction.type === Discord.InteractionType.ApplicationCommand){

      const cmd = client.slashCommands.get(interaction.commandName);

      if (!cmd) return interaction.reply(`Error`);

      interaction["member"] = interaction.guild.members.cache.get(interaction.user.id);

      cmd.run(client, interaction)

   }
})

client.on('ready', () => {
  console.log(`🔧 Aplicação Iniciada Com Sucesso ${client.user.username}!`)
})


client.slashCommands = new Discord.Collection()

require('./handler')(client)

client.login(config.token)

  client.on("interactionCreate", async interaction => {
    if (interaction.isButton()) {
      if (interaction.customId.startsWith("alterar_username")) {
        const modal_bot_config_nome = new Discord.ModalBuilder()
          .setCustomId('modal_bot_config_nome')
          .setTitle(`Altere informações do bot abaixo.`)
        const nome_bot = new Discord.TextInputBuilder()
          .setCustomId('username_bot')
          .setLabel('Digite o nome do bot.')
          .setPlaceholder('Escreva o nome aqui.')
          .setStyle(Discord.TextInputStyle.Short)
  
        const firstActionRow = new Discord.ActionRowBuilder().addComponents(nome_bot);
        modal_bot_config_nome.addComponents(firstActionRow)
        await interaction.showModal(modal_bot_config_nome);
      }
    }
  
    if (interaction.isButton()) {
      if (interaction.customId.startsWith("alterar_avatar")) {
        const modal_bot_config_avatar = new Discord.ModalBuilder()
          .setCustomId('modal_bot_config_avatar')
          .setTitle(`Altere informações do bot abaixo.`)
        const avatar_bot_modal = new Discord.TextInputBuilder()
          .setCustomId('bot_avatar')
          .setLabel('URL do avatar.')
          .setPlaceholder('URL aqui')
          .setStyle(Discord.TextInputStyle.Short)
        const SecondActionRow = new Discord.ActionRowBuilder().addComponents(avatar_bot_modal)
        modal_bot_config_avatar.addComponents(SecondActionRow)
        await interaction.showModal(modal_bot_config_avatar);
      }
    }
    //
    if (!interaction.isModalSubmit()) return;
    if (interaction.customId === 'modal_bot_config_nome') {
      const nome_bot = interaction.fields.getTextInputValue('username_bot');
  
      await interaction.reply({
        ephemeral: true,
        embeds: [
          new Discord.EmbedBuilder()
            .setColor("Black")
            .setDescription(`**${interaction.user.tag},** Alterei o meu nome para:`)
            .addFields(
              {
                name: `\\🌟 Nome alterado para:`,
                value: `\`\`\`fix\n${nome_bot}\n\`\`\``,
              },
            )
            .setTimestamp()
            .setFooter({ text: interaction.user.username, iconURL: interaction.user.displayAvatarURL({ dinamyc: true }) })
        ]
      })
      interaction.client.user.setUsername(nome_bot)
    }
    //
    if (!interaction.isModalSubmit()) return;
    if (interaction.customId === 'modal_bot_config_avatar') {
      const avatar_bot = interaction.fields.getTextInputValue('bot_avatar');
  
      interaction.reply({
        ephemeral: true,
        embeds: [
          new Discord.EmbedBuilder()
            .setColor("White")
            .setDescription(`**${interaction.user.tag},** Alterei o meu avatar para:`)
            .setImage(avatar_bot)
            .setFooter({ text: interaction.user.username, iconURL: interaction.user.displayAvatarURL({ dinamyc: true }) })
        ]
      })
      interaction.client.user.setAvatar(avatar_bot)
    }
  })

  process.on("uncaughtException", (err) => {
    console.log("Uncaught Exception: " + err);
});
  
process.on("unhandledRejection", (reason, promise) => {
    console.log("[GRAVE] Rejeição possivelmente não tratada em: Promise ", promise, " motivo: ", reason.message);
});

const { QuickDB } = require('quick.db')
const db = new QuickDB()

client.on('messageCreate', async (message) => {

  if (message.author.bot) return;
  if (message.channel.type == 'dm') return;

  let verificando = await db.get(`antilink_${message.guild.id}`);
  if (!verificando || verificando === "off" || verificando === null || verificando === false) return;

  if (verificando === "on") {

    if (!message.channel.permissionsFor(message.author).has(Discord.PermissionFlagsBits.ManageGuild))
      if (!message.channel.permissionsFor(message.author).has(Discord.PermissionFlagsBits.Administrator))

        if (message.content.includes("https".toLowerCase() || "http".toLowerCase() || "www".toLowerCase() || ".com".toLowerCase() || ".br".toLowerCase())) {

          message.delete();
          message.channel.send({
            content: `${message.author}`,
            embeds: [
              new Discord.EmbedBuilder()
                .setTitle(`System`)
                .setDescription(`**${message.author.tag},** Você não pode enviar links aqui.`)
                .setColor("#000000")
                .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL({ dinamyc: true }) })
            ]
          })
        }
  }
})

/*
Types:
0 = Jogando
2 = Ouvindo
3 = Assistindo
*/

client.on("ready", () => {

  const activities = [
    { name: ` UNKNOWM SYSTEM ON`, type: 0 }, 
    { name: ` UNKNOWM SYSTEM ON`, type: 0 },
    { name: ` UNKNOWM SYSTEM ON`, type: 0 },
  ];
  
  const status = [
    'online'
  ];
  
  let i = 0;
  setInterval(() => {
    if(i >= activities.length) i = 0
    client.user.setActivity(activities[i])
    i++;
  }, 10 * 500);
  
  let s = 0;
});

require('../index')

const Discord = require('discord.js')
const client = require('../index')

client.on("guildMemberAdd", (member) => {
    let cargo_autorole = member.guild.roles.cache.get("850189027976937482") // Coloque o ID do cargo
    if (!cargo_autorole) return console.log("❌ O AUTOROLE não está configurado.")

    member.roles.add(cargo_autorole.id).catch(err => {
      console.log(`❌ Não foi possível adicionar o cargo de autorole no usuário ${member.user.tag}.`)
    })
  });